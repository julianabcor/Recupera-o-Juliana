CREATE TABLE departamento (
    id_departamento INT PRIMARY KEY AUTO_INCREMENT,
    nome_departamento VARCHAR(20) NOT NULL,
    local_departamento VARCHAR(30)
);

CREATE TABLE colaboradores (
    id_colaborador INT PRIMARY KEY AUTO_INCREMENT,
    nome_colaborador VARCHAR(30) NOT NULL,
    cpf_colaborador CHAR(15) UNIQUE,
    email_colaborador VARCHAR(30),
    cargo_colaborador VARCHAR(20),
    data_admissao_colaborador DATE
    id_departamento INT,
    FOREIGN KEY (id_departamento) 
        REFERENCES departamento(id_departamento),
);

CREATE TABLE equipamento (
    id_equipamento INT PRIMARY KEY AUTO_INCREMENT,
    nome_equipamento VARCHAR(30),
    patrimonio_equipamento
);
