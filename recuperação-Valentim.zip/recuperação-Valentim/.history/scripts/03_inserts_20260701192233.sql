INSERT INTO(nome_departamento, local_departamento)VALUES
('Produção','Zona leste'),
('Engenharia','Zona oeste'),
('Qualidade','Zona sul'),
('Logística','Zona norte'),
('Tecnologia da Informação','Zona centro-oeste');

INSERT INTO(nome_colaborador, cpf_colaborador, email_colaborador, cargo_colaborador, data_admissao_colaborador)VALUES
('João Silva','')