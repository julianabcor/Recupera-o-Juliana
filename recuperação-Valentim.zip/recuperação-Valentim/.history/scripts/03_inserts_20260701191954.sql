INSERT INTO('nome_departamento', 'local_departamento)VALUES
('Produção','Zona leste'),
('Engenharia','Zona oeste'),
('Qualidade','Zona sul'),
('Logística','Zona norte'),
('Tecnologia da Informação','Zona centro-oeste');