CREATE TABLE departamento (
    id_departamento INT PRIMARY KEY AUTO_INCREMENT
    nome_departamento VARCHAR(20)
)