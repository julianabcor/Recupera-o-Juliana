INSERT INTO(nome_departamento, local_departamento)VALUES
('Produção','Zona leste');