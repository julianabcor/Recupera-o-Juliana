INSERT INTO(nome_departamento, local_departamento)VALUES
('Produção','Zona leste'),
('Engenharia','Zona oeste'),
('Qualidade','Zona sul'),
('Produção','Zona norte'),
('','Zona centro-oeste'),