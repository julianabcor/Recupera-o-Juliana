CREATE TABLE departamento (
    id_departamento INT PRIMARY KEY AUTO_INCREMENT,
    nome_departamento VARCHAR(20) NOT NULL,
    local_departamento VARCHAR(30)
);

CREATE TABLE colaboradores (
    id_colaborador INT PRIMARY KEY AUTO_INCREMENT,
    nome_colaborador VARCHAR(30) NOT NULL,
    cpf_colaborador CHAR(15) UNIQUE,
    email_colaborador VARCHAR(30),
    cargo_colaborador VARCHAR(20),
    data_admissao_colaborador DATE
    id_departamento INT,
    FOREIGN KEY (id_departamento) 
        REFERENCES departamento(id_departamento),
);

CREATE TABLE equipamento (
    id_equipamento INT PRIMARY KEY AUTO_INCREMENT,
    nome_equipamento VARCHAR(30),
    patrimonio_equipamento INT,
    descricao_equipamento TEXT,
    fabricante_equipamento VARCHAR(30),
    modelo_equipamento VARCHAR(30),
    data_aquisicao_equipamento DATE,
    status_equipamento ENUM('FUNCIONANDO','PARADO'),
    FOREIGN KEY (id_categoria)
        REFERENCES categoria(id_categoria)
);

CREATE TABLE categoria (
    id_categoria INT PRIMARY KEY AUTO_INCREMENT,
    nome_categoria VARCHAR(20),
    descricao_categoria TEXT
);

CREATE TABLE fornecedor (
    id_fornecedor INT PRIMARY KEY AUTO_INCREMENT,
    nome_fornecedor VARCHAR(30),
    cnpj_fornecedor CHAR(15),
    telefone_fornecedor CHAR(20),
    cidade_fornecedor VARCHAR(30)
);

CREATE TABLE chamado (
    id_chamado INT PRIMARY KEY AUTO_INCREMENT,
    data_chamado DATE,
    descricao_chamado TEXT,
    prioridade_chamado ENUM('URGENTE','NÃO URGENTE'),
    status_chamado ENUM('CONCLUÍDO','EM ANDAMENTO','NÃO INICIADO')
    data_encerramento_chamado DATE,
    id_colaborador INT,
    id_equipamento INT,
    FOREIGN KEY (id_colaborador)
    
);