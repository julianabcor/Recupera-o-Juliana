INSERT INTO(nome_departamento, local_departamento)VALUES
('Produção','Zona leste'),
('Engenharia','Zona oeste'),
('Qualidade','Zona sul'),
('Logística','Zona norte'),
('Tecnologia da Informação','Zona centro-oeste');

INSERT INTO(nome_colaborador, cpf_colaborador, email_colaborador, cargo_colaborador, data_admissao_colaborador)VALUES
('João Silva','111.111.111-11','joaosilva@email.com','Operador','01-05-2022'),
('Lucas Santos','222.222.222-22','lucassantos@email.com','Técnico','01-02-2023'),
('Marina Souza','333.333.333-33','marinasouza@email.com','Gerente','01-09-2024')
('Bruna Carvalho','444.444.444-44','brunacarvalho@email.com','Operador','01-07-2025')
('Felipe Ferreira','555.555.555-55','felipeferreira@email.com','','01-05-2022')
