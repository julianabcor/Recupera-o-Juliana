CREATE TABLE departamento (
    id_departamento INT PRIMARY KEY AUTO_INCREMENT
    nome_departamento VARCHAR(20) NOT NULL,
    local_departamento VARCHAR(30)
);

CREATE TABLE colaboradores (
    id_colaborador INT PRIMARY KEY AUTO_INCREMENT
    nome_colaborador
);