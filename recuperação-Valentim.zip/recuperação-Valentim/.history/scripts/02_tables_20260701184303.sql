CREATE TABLE departamento (
    id_departamento
)