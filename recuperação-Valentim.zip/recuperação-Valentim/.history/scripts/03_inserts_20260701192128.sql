INSERT INTO(nome_departamento, local_departamento)VALUES
('Produção','Zona leste'),
('Engenharia','Zona oeste'),
('Qualidade','Zona sul'),
('Logística','Zona norte'),
('Tecnologia da Informação','Zona centro-oeste');

INSERT INTO(nome_colaborador VARCHAR(30) NOT NULL,
    cpf_colaborador CHAR(15) UNIQUE,
    email_colaborador,
    cargo_colaborador,
    data_admissao_colaborador)