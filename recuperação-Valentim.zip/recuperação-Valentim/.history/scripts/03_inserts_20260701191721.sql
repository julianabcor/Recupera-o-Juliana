INSERT INTO(inome_departamento, local_departamento)VALUES
()