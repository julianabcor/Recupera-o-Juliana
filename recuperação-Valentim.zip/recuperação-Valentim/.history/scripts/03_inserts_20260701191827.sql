INSERT INTO(nome_departamento, local_departamento)VALUES
('Produção','Zona leste'),
('Engenharia','Zona oeste'),
('Qualidade','Zona leste'),
('Produção','Zona leste'),
('Produção','Zona leste'),