INSERT INTO(nome_departamento, local_departamento)VALUES
('Produção','Zona leste'),
('Engenharia','Zona oeste'),
('Produção','Zona leste'),
('Produção','Zona leste'),
('Produção','Zona leste'),