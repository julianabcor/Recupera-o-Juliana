INSERT INTO(id_departamento, nome_departamento, local_departamento)VALUES
()