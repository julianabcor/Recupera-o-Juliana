INSERT INTO(id_departamentonome_departamento 
    local_departamento)